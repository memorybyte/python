from pathlib import Path

print(f'Initialized: {Path.home()}')